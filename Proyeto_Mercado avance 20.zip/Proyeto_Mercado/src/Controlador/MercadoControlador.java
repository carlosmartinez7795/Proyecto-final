/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Nodo;
import Modelo.Producto;

/**
 *
 * @author Compaq 18
 */
public class MercadoControlador {
    private Nodo cabeza;

    public Nodo getCabeza() {
        return cabeza;
    }

    // Método para agregar un producto a la lista (uso interno o si decides usarlo después)
    public void agregarProducto(Producto nuevoProducto) {
        Nodo nuevoNodo = new Nodo(nuevoProducto);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
    }

    public String mostrarProductos() {
        StringBuilder sb = new StringBuilder("Productos en el mercado:\n");
        Nodo actual = cabeza;
        if (actual == null) {
            return "El mercado está vacío.";
        }
        while (actual != null) {
            sb.append(actual.dato.toString()).append("\n");
            actual = actual.siguiente;
        }
        return sb.toString();
    }

   

}
    

