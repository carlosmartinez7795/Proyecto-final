
package Controlador;

import Modelo.Nodo; 
import Vista.Catalogo;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JLabel lblUsuario;
    private JLabel lblContrasena;
    private Nodo nodoAutenticado; // Ahora es de tipo Nodo

    public Login() {
        setTitle("Login");
        setSize(300, 180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        lblUsuario = new JLabel("Usuario:");
        lblContrasena = new JLabel("Contraseña:");
        txtUsuario = new JTextField();
        txtContrasena = new JPasswordField();
        btnIngresar = new JButton("Ingresar");

        lblUsuario.setBounds(30, 20, 80, 25);
        txtUsuario.setBounds(120, 20, 130, 25);
        lblContrasena.setBounds(30, 55, 80, 25);
        txtContrasena.setBounds(120, 55, 130, 25);
        btnIngresar.setBounds(90, 95, 100, 30);

        add(lblUsuario);
        add(txtUsuario);
        add(lblContrasena);
        add(txtContrasena);
        add(btnIngresar);

        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuarioIngresado = txtUsuario.getText();
                String pass = new String(txtContrasena.getPassword());

                UsuarioControlador uc = new UsuarioControlador();
                Nodo nodoAutenticado = (Nodo) uc.validar(usuarioIngresado, pass);

                if (nodoAutenticado != null) {
                    JOptionPane.showMessageDialog(Login.this, "Bienvenido");
                    Catalogo catalogo = new Catalogo();
                    catalogo.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(Login.this, "Usuario o contraseña incorrecta");
                }
            }
        });
    }

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
}
