/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ItemCarrito;
import Modelo.NodoCarrito;
import Modelo.Producto;

/**
 *
 * @author Compaq 18
 */
public class CarritoCompras {
    private NodoCarrito cabeza;

    public CarritoCompras() {
        this.cabeza = null;
    }

    public void agregarItem(Producto producto, int cantidad) {
        ItemCarrito nuevoItem = new ItemCarrito(producto, cantidad);
        NodoCarrito nuevoNodo = new NodoCarrito(nuevoItem);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            NodoCarrito actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
    }

    public void eliminarItem(String nombreProducto) {
        if (cabeza == null) {
            return;
        }
        if (cabeza.item.getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
            cabeza = cabeza.siguiente;
            return;
        }
        NodoCarrito actual = cabeza;
        while (actual.siguiente != null) {
            if (actual.siguiente.item.getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
                actual.siguiente = actual.siguiente.siguiente;
                return;
            }
            actual = actual.siguiente;
        }
    }

    public void actualizarCantidad(String nombreProducto, int nuevaCantidad) {
        NodoCarrito actual = cabeza;
        while (actual != null) {
            if (actual.item.getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
                actual.item.setCantidad(nuevaCantidad);
                return;
            }
            actual = actual.siguiente;
        }
    }

    public double calcularTotal() {
        double total = 0;
        NodoCarrito actual = cabeza;
        while (actual != null) {
            total += actual.item.calcularSubtotal();
            actual = actual.siguiente;
        }
        return total;
    }

    public String mostrarCarrito() {
        StringBuilder sb = new StringBuilder("Carrito de Compras:\n");
        NodoCarrito actual = cabeza;
        if (actual == null) {
            return "El carrito está vacío.";
        }
        while (actual != null) {
            sb.append(actual.item.toString()).append("\n");
            actual = actual.siguiente;
        }
        sb.append("------------------------\n");
        sb.append("Total: $").append(String.format("%.2f", calcularTotal()));
        return sb.toString();
    }

    public NodoCarrito getCabeza() {
        return cabeza;
    }
}

    

