
package Modelo;

/**
 *
 * @author Compaq 18
 */

public class Nodo {
    public String nombreUsuario;
    public String contrasena;
    public Nodo siguiente;
    public Producto dato;

    public Nodo(String nombreUsuario, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.siguiente = null;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }
    
    public Nodo(Producto dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
