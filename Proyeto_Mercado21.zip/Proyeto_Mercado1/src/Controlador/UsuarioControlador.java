/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author Compaq 18
 */
import Modelo.Nodo;

public class UsuarioControlador {
    private Nodo cabeza;

    public UsuarioControlador() {
        this.cabeza = null;
        agregarNodo("admin", "123");
        agregarNodo("user1", "12345");
        agregarNodo("Daniela","0928");
        
    }

    public void agregarNodo(String nombreUsuario, String contrasena) {
        Nodo nuevoNodo = new Nodo(nombreUsuario, contrasena);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
    }

    public Nodo validar(String usuario, String contrasena) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.getNombreUsuario().equals(usuario) && actual.getContrasena().equals(contrasena)) {
                return actual; 
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void imprimirLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println("Usuario: " + actual.getNombreUsuario() + ", Contraseña: " + actual.getContrasena());
            actual = actual.siguiente;
        }
    }
}

